import random
import time
import csv
import sys

# Treap implementation
type_hint = None

class TreapNode:
    __slots__ = ('key', 'priority', 'left', 'right')
    def __init__(self, key):
        self.key = key
        self.priority = random.random()
        self.left = None
        self.right = None

class Treap:
    def __init__(self):
        self.root = None

    def split(self, root, key):
        if root is None:
            return (None, None)
        if key < root.key:
            left, root.left = self.split(root.left, key)
            return (left, root)
        else:
            root.right, right = self.split(root.right, key)
            return (root, right)

    def merge(self, left, right):
        if not left or not right:
            return left or right
        if left.priority > right.priority:
            left.right = self.merge(left.right, right)
            return left
        else:
            right.left = self.merge(left, right.left)
            return right

    def insert(self, key):
        node = TreapNode(key)
        left, right = self.split(self.root, key)
        self.root = self.merge(self.merge(left, node), right)

    def remove(self, key):
        left, mid = self.split(self.root, key)
        mid, right = self.split(mid, key+1)
        self.root = self.merge(left, right)

    def search(self, key):
        node = self.root
        while node:
            if key < node.key:
                node = node.left
            elif key > node.key:
                node = node.right
            else:
                return True
        return False

    def max_depth(self, node=None):
        if node is None:
            node = self.root
        def _depth(n):
            if not n:
                return 0
            return max(_depth(n.left), _depth(n.right)) + 1
        return _depth(node)

    def branch_depths(self, node=None, depth=0, depths=None):
        if depths is None:
            depths = []
        if node is None:
            node = self.root
        if node.left is None and node.right is None:
            depths.append(depth)
        if node.left:
            self.branch_depths(node.left, depth+1, depths)
        if node.right:
            self.branch_depths(node.right, depth+1, depths)
        return depths

# AVL implementation
class AVLNode:
    __slots__ = ('key', 'height', 'left', 'right')
    def __init__(self, key):
        self.key = key
        self.height = 1
        self.left = None
        self.right = None

class AVL:
    def __init__(self):
        self.root = None

    def height(self, node):
        return node.height if node else 0

    def balance_factor(self, node):
        return self.height(node.left) - self.height(node.right) if node else 0

    def rotate_right(self, y):
        x = y.left
        T2 = x.right
        x.right = y
        y.left = T2
        y.height = max(self.height(y.left), self.height(y.right)) + 1
        x.height = max(self.height(x.left), self.height(x.right)) + 1
        return x

    def rotate_left(self, x):
        y = x.right
        T2 = y.left
        y.left = x
        x.right = T2
        x.height = max(self.height(x.left), self.height(x.right)) + 1
        y.height = max(self.height(y.left), self.height(y.right)) + 1
        return y


    def insert_node(self, node, key):
        if not node:
            return AVLNode(key)
        if key < node.key:
            node.left = self.insert_node(node.left, key)
        elif key > node.key:
            node.right = self.insert_node(node.right, key)
        else:
            return node
        node.height = max(self.height(node.left), self.height(node.right)) + 1
        balance = self.balance_factor(node)
        if balance > 1 and key < node.left.key:
            return self.rotate_right(node)
        if balance < -1 and key > node.right.key:
            return self.rotate_left(node)
        if balance > 1 and key > node.left.key:
            node.left = self.rotate_left(node.left)
            return self.rotate_right(node)
        if balance < -1 and key < node.right.key:
            node.right = self.rotate_right(node.right)
            return self.rotate_left(node)
        return node

    def insert(self, key):
        self.root = self.insert_node(self.root, key)

    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

    def remove_node(self, node, key):
        if not node:
            return node
        if key < node.key:
            node.left = self.remove_node(node.left, key)
        elif key > node.key:
            node.right = self.remove_node(node.right, key)
        else:
            if not node.left or not node.right:
                node = node.left or node.right
            else:
                temp = self.min_value_node(node.right)
                node.key = temp.key
                node.right = self.remove_node(node.right, temp.key)
        if not node:
            return node
        node.height = max(self.height(node.left), self.height(node.right)) + 1
        balance = self.balance_factor(node)
        if balance > 1 and self.balance_factor(node.left) >= 0:
            return self.rotate_right(node)
        if balance > 1 and self.balance_factor(node.left) < 0:
            node.left = self.rotate_left(node.left)
            return self.rotate_right(node)
        if balance < -1 and self.balance_factor(node.right) <= 0:
            return self.rotate_left(node)
        if balance < -1 and self.balance_factor(node.right) > 0:
            node.right = self.rotate_right(node.right)
            return self.rotate_left(node)
        return node

    def remove(self, key):
        self.root = self.remove_node(self.root, key)

    def search(self, key):
        node = self.root
        while node:
            if key < node.key:
                node = node.left
            elif key > node.key:
                node = node.right
            else:
                return True
        return False

    def max_depth(self, node=None):
        if node is None:
            node = self.root
        def _depth(n):
            if not n:
                return 0
            return max(_depth(n.left), _depth(n.right)) + 1
        return _depth(node)

    def branch_depths(self, node=None, depth=0, depths=None):
        if depths is None:
            depths = []
        if node is None:
            node = self.root
        if node.left is None and node.right is None:
            depths.append(depth)
        if node.left:
            self.branch_depths(node.left, depth+1, depths)
        if node.right:
            self.branch_depths(node.right, depth+1, depths)
        return depths


# Benchmark harness
def run_series(N, repetitions=50):
    results = []
    for _ in range(repetitions):
        values = list(range(N))
        random.shuffle(values)
        treap = Treap()
        avl = AVL()
        # build
        start = time.time()
        for v in values:
            treap.insert(v)
        treap_depth = treap.max_depth()
        t_build = time.time() - start
        start = time.time()
        for v in values:
            avl.insert(v)
        avl_depth = avl.max_depth()
        a_build = time.time() - start
        # insert ops
        start = time.time()
        for _ in range(1000):
            treap.insert(random.randrange(N))
        t_ins = time.time() - start
        start = time.time()
        for _ in range(1000):
            avl.insert(random.randrange(N))
        a_ins = time.time() - start
        # remove ops
        start = time.time()
        for _ in range(1000):
            treap.remove(random.randrange(N))
        t_rem = time.time() - start
        start = time.time()
        for _ in range(1000):
            avl.remove(random.randrange(N))
        a_rem = time.time() - start
        # search ops
        start = time.time()
        for v in values:
            treap.search(v)
        t_search = time.time() - start
        start = time.time()
        for v in values:
            avl.search(v)
        a_search = time.time() - start
        # branch depths
        t_br = treap.branch_depths()
        a_br = avl.branch_depths()
        results.append({
            'N': N,
            'treap_build': t_build,
            'avl_build': a_build,
            'treap_max_depth': treap_depth,
            'avl_max_depth': avl_depth,
            'treap_insert': t_ins,
            'avl_insert': a_ins,
            'treap_remove': t_rem,
            'avl_remove': a_rem,
            'treap_search': t_search,
            'avl_search': a_search,
            'treap_branch_depths': t_br,
            'avl_branch_depths': a_br,
        })
    return results

if __name__ == '__main__':
    with open('results.csv', 'w', newline='') as csvfile:
        fieldnames = ['N', 'treap_build','avl_build','treap_max_depth','avl_max_depth',
                      'treap_insert','avl_insert','treap_remove','avl_remove',
                      'treap_search','avl_search','treap_branch_depths','avl_branch_depths']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        for i in range(10, 19):
            res = run_series(1<<i)
            for r in res:
                writer.writerow(r)
    print('Benchmark complete. Results saved to results.csv')
